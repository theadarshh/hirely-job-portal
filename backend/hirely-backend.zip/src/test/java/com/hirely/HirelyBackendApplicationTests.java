package com.hirely;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HirelyBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
